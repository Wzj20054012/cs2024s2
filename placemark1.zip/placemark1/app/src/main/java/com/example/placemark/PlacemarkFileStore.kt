package com.example.placemark

import android.content.Context
import android.net.Uri
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.TypeAdapter
import com.google.gson.stream.JsonReader
import com.google.gson.stream.JsonWriter
import timber.log.Timber
import java.io.File

class PlacemarkFileStore(private val context: Context) : PlacemarkStore {

    private val gson: Gson = GsonBuilder()
        .registerTypeAdapter(Uri::class.java, UriAdapter())
        .create()

    private val file = File(context.filesDir, "placemarks.json")
    private val placemarks = mutableListOf<Placemark>()
    private var nextId = 0L

    init {
        loadFromFile()
        nextId = placemarks.maxOfOrNull { it.id }?.plus(1) ?: 0L
    }

    override fun findAll(): List<Placemark> {
        return placemarks.toList()
    }

    override fun create(placemark: Placemark) {
        placemark.id = nextId++
        placemarks.add(placemark)
        saveToFile()
        logAll()
    }

    override fun update(placemark: Placemark) {
        val index = placemarks.indexOfFirst { it.id == placemark.id }
        if (index != -1) {
            placemarks[index] = placemark
            saveToFile()
            logAll()
        }
    }

    override fun delete(placemark: Placemark) {
        placemarks.removeAll { it.id == placemark.id }
        saveToFile()
        logAll()
    }

    private fun loadFromFile() {
        if (!file.exists()) {
            placemarks.clear()
            return
        }
        try {
            val jsonContent = file.readText()
            val type = object : com.google.gson.reflect.TypeToken<List<Placemark>>() {}.type
            val loadedList = gson.fromJson<List<Placemark>>(jsonContent, type)
            placemarks.clear()
            placemarks.addAll(loadedList)
        } catch (e: Exception) {
            Timber.e("加载数据文件失败: ${e.message}")
            placemarks.clear()
        }
    }

    private fun saveToFile() {
        try {
            val jsonContent = gson.toJson(placemarks)
            file.writeText(jsonContent)
        } catch (e: Exception) {
            Timber.e("保存数据文件失败: ${e.message}")
        }
    }

    private fun logAll() {
        placemarks.forEach { Timber.i("$it") }
    }

    private class UriAdapter : TypeAdapter<Uri>() {
        override fun write(out: JsonWriter, value: Uri?) {
            out.value(value?.toString())
        }

        override fun read(`in`: JsonReader): Uri {
            val uriString = `in`.nextString()
            return if (uriString.isNullOrEmpty()) Uri.EMPTY else Uri.parse(uriString)
        }
    }
}