package com.example.placemark

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.placemark.databinding.CardPlacemarkBinding

interface PlacemarkListener {
    fun onPlacemarkClick(placemark: Placemark)
}

class PlacemarkAdapter constructor(
    private var placemarks: List<Placemark>,
    private val listener: PlacemarkListener
) : RecyclerView.Adapter<PlacemarkAdapter.MainHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MainHolder {
        val binding = CardPlacemarkBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return MainHolder(binding)
    }

    override fun onBindViewHolder(holder: MainHolder, position: Int) {
        val placemark = placemarks[position]
        holder.bind(placemark, listener)
    }

    override fun getItemCount(): Int = placemarks.size

    class MainHolder(private val binding: CardPlacemarkBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(placemark: Placemark, listener: PlacemarkListener) {
            binding.placemarkTitle.text = placemark.title
            binding.description.text = placemark.description
            binding.placemarkCoordinates.text = "Lat: ${placemark.lat}, Lng: ${placemark.lng}"
            binding.root.setOnClickListener { listener.onPlacemarkClick(placemark) }
        }
    }
}