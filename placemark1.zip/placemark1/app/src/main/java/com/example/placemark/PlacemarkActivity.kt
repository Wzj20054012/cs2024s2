package com.example.placemark

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.placemark.databinding.ActivityPlacemarkBinding
import com.google.android.material.snackbar.Snackbar
import com.squareup.picasso.Picasso
import timber.log.Timber

class PlacemarkActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlacemarkBinding
    private lateinit var app: MainApp
    private lateinit var imageIntentLauncher: ActivityResultLauncher<PickVisualMediaRequest>
    private lateinit var mapIntentLauncher: ActivityResultLauncher<Intent>
    private var placemark = Placemark()
    private var edit = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityPlacemarkBinding.inflate(layoutInflater)
        setContentView(binding.root)

        app = application as MainApp

        registerImagePickerCallback()
        registerMapCallback()

        if (intent.hasExtra("placemark_edit")) {
            edit = true
            val placemarkExtra = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableExtra("placemark_edit", Placemark::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra("placemark_edit")
            }
            placemarkExtra?.let {
                placemark = it
            }
            binding.placemarkTitle.setText(placemark.title)
            binding.placemarkDescription.setText(placemark.description)
            binding.btnAddPlacemark.setText(R.string.save_placemark)

            if (placemark.image != Uri.EMPTY) {
                Picasso.get()
                    .load(placemark.image)
                    .into(binding.placemarkImage)
                binding.chooseImage.setText("Change Image")
            }
        }

        binding.btnAddPlacemark.setOnClickListener {
            placemark.title = binding.placemarkTitle.text.toString()
            placemark.description = binding.placemarkDescription.text.toString()

            if (placemark.title.isEmpty()) {
                Snackbar.make(it, R.string.hint_enter_title, Snackbar.LENGTH_LONG).show()
            } else {
                if (edit) {
                    app.store.update(placemark.copy())
                } else {
                    app.store.create(placemark.copy())
                }

                val resultIntent = Intent()
                resultIntent.putExtra("placemark_edit", placemark)
                setResult(RESULT_OK, resultIntent)
                finish()
            }
        }

        binding.chooseImage.setOnClickListener {
            val request = PickVisualMediaRequest.Builder()
                .setMediaType(ActivityResultContracts.PickVisualMedia.ImageOnly)
                .build()
            imageIntentLauncher.launch(request)
        }

        binding.placemarkLocation.setOnClickListener {
            val location = Location(52.245696, -7.139102, 15f)
            if (placemark.zoom != 0f) {
                location.lat = placemark.lat
                location.lng = placemark.lng
                location.zoom = placemark.zoom
            }
            val launcherIntent = Intent(this, MapActivity::class.java).apply {
                putExtra("location", location)
            }
            mapIntentLauncher.launch(launcherIntent)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_placemark, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.item_delete -> {
                if (edit) {
                    app.store.delete(placemark)
                    setResult(RESULT_OK)
                }
                finish()
                true
            }
            R.id.item_cancel -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun registerImagePickerCallback() {
        imageIntentLauncher = registerForActivityResult(
            ActivityResultContracts.PickVisualMedia()
        ) {
            try {
                contentResolver.takePersistableUriPermission(
                    it!!,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
                placemark.image = it
                Timber.i("IMG :: ${placemark.image}")
                Picasso.get()
                    .load(placemark.image)
                    .into(binding.placemarkImage)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun registerMapCallback() {
        mapIntentLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                val locationExtra = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    result.data!!.getParcelableExtra("location", Location::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    result.data!!.getParcelableExtra<Location>("location")
                }
                locationExtra?.let {
                    placemark.lat = it.lat
                    placemark.lng = it.lng
                    placemark.zoom = it.zoom
                    Timber.i("Location == $placemark")
                }
            }
        }
    }
}