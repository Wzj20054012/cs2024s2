package com.example.placemark

import timber.log.Timber

class PlacemarkMemStore : PlacemarkStore {

    private val placemarks = ArrayList<Placemark>()

    override fun findAll(): List<Placemark> {
        return placemarks
    }

    override fun create(placemark: Placemark) {
        placemark.id = getId()
        placemarks.add(placemark)
        logAll()
    }

    override fun update(placemark: Placemark) {
        val foundPlacemark: Placemark? = placemarks.find { p -> p.id == placemark.id }
        if (foundPlacemark != null) {
            foundPlacemark.title = placemark.title
            foundPlacemark.description = placemark.description
            foundPlacemark.image = placemark.image
            foundPlacemark.lat = placemark.lat
            foundPlacemark.lng = placemark.lng
            foundPlacemark.zoom = placemark.zoom
            logAll()
        }
    }

    override fun delete(placemark: Placemark) {
        placemarks.remove(placemark)
        logAll()
    }

    private fun logAll() {
        placemarks.forEach { Timber.i("$it") }
    }

    companion object {
        private var lastId = 0L
        fun getId(): Long = lastId++
    }
}