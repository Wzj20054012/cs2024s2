package com.example.placemark

interface PlacemarkStore {
    fun findAll(): List<Placemark>
    fun create(placemark: Placemark)
    fun update(placemark: Placemark)
    fun delete(placemark: Placemark)
}