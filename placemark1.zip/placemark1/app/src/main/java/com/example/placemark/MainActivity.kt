package com.example.placemark

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.placemark.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity(), PlacemarkListener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var app: MainApp
    private lateinit var adapter: PlacemarkAdapter
    private lateinit var refreshIntentLauncher: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        app = application as MainApp

        refreshIntentLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                adapter.notifyDataSetChanged()
            }
        }

        adapter = PlacemarkAdapter(app.store.findAll(), this)

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.item_add -> {
                val intent = Intent(this, PlacemarkActivity::class.java)
                refreshIntentLauncher.launch(intent)
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onPlacemarkClick(placemark: Placemark) {
        val intent = Intent(this, PlacemarkActivity::class.java)
        intent.putExtra("placemark_edit", placemark)
        refreshIntentLauncher.launch(intent)
    }
}