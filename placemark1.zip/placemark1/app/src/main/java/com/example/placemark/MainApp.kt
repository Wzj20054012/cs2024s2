package com.example.placemark

import android.app.Application
import timber.log.Timber

class MainApp : Application() {

    lateinit var store: PlacemarkStore

    override fun onCreate() {
        super.onCreate()
        Timber.plant(Timber.DebugTree())
        Timber.i("Placemark started")
        store = PlacemarkJSONStore(applicationContext)
    }
}