package com.example.placemark.helpers

import android.content.Intent
import androidx.activity.result.ActivityResultLauncher

fun showImagePicker(intentLauncher: ActivityResultLauncher<Intent>) {
    val chooseFile = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
        type = "image/*"
        addCategory(Intent.CATEGORY_OPENABLE)
    }
    val chooser = Intent.createChooser(chooseFile, "Select placemark image")
    intentLauncher.launch(chooser)
}